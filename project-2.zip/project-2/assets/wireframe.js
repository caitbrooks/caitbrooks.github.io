$(document).ready(function (){
    
 $("#cloudbutton").click(function (){
     $("#mycloud").toggleClass("visible");
     $("#cloudbutton").toggleClass("green-button");
 });       
});

$(document).ready(function (){
        $("#sunbutton").click(function (){
     $("#mysun").toggleClass("visible");
     $("#sunbutton").toggleClass("green-button");
 });  
});

$(document).ready(function (){
        $("#wavebutton").click(function (){
     $("#mywave").toggleClass("visible");
     $("#wavebutton").toggleClass("green-button");
 });  
});

$(document).ready(function (){
        $("#plantbutton").click(function (){
     $("#myplant").toggleClass("visible");
     $("#plantbutton").toggleClass("green-button");
 });  
});

$(document).ready(function (){
        $("#towelbutton").click(function (){
     $("#mytowel").toggleClass("visible");
     $("#towelbutton").toggleClass("green-button");
 });  
});

$(document).ready(function (){
        $("#castlebutton").click(function (){
     $("#mycastle").toggleClass("visible");
     $("#castlebutton").toggleClass("green-button");
 });  
});
$(document).ready(function (){
        $("#rockbutton").click(function (){
     $("#myrock").toggleClass("visible");
     $("#rockbutton").toggleClass("green-button");
 });  
});